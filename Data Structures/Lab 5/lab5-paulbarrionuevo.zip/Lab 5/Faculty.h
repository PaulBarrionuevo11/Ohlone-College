#ifndef FACULTY_H
#define FACULTY_H

#include <iostream>

using namespace std;

class Faculty
{
public:
	Faculty() {}
	~Faculty() {}

	// Getters
	string getInstructor() { return instructor; }
	string getFirstName() { return firstName; }
	string getLastName() { return lastName; }
	string getDepartment() { return department; }
	string getAddress() { return address; }
	string getCity() { return city; }
	string getState() { return state; }
	string getZip() { return zip; }
	string getEmail() { return email; }
	string getPhone() { return phone; }
	// Setters 
	void setInstructor(string _inst) { instructor = _inst; }
	void setFirstName(string _firstN) { firstName = _firstN; }
	void setLastName(string _lastN) { lastName = _lastN; }
	void setDepartment(string _dep) { department = _dep; }
	void setAddress(string _addr) { address = _addr; }
	void setCity(string _city) { city = _city; }
	void setState(string _state) { state = _state; }
	void setZip(string _zip) { zip = _zip; }
	void setEmail(string _email) { email = _email; }
	void setPhone(string _phone) { phone = _phone; }
	int hash_code(const std::string& str) {
		int h = 0;
		for (char c : str) {
			h = 31 * h + c;
		}
		return h;
	}
private:
	string instructor, firstName, lastName, department, address, city, state, zip, email, phone;

};
#endif // !FACULTY_H
