//#include "FacultyList.h"
//#include <sstream>
//#include <fstream>
//
//void FacultyList::init()
//{
//	// read faculty_data.csv
//	string FACULTY_DATA = "C:/Users/pable/Documents/Github/Ohlone/Data Structures/Downloads/faculty_data.csv";
//	ifstream inFile(FACULTY_DATA);
//
//	try
//	{
//		string line;
//		getline(inFile, line); // Skip header
//		while (getline(inFile, line))
//		{
//			istringstream ss(line);
//			string instructorId, value;
//			Faculty faculty;
//
//			getline(ss, instructorId, ' ');
//			faculty.setInstructor(instructorId);
//			getline(ss, value, ' ');
//			faculty.setFirstName(value);
//			getline(ss, value, ' ');
//			faculty.setLastName(value);
//			getline(ss, value, ' ');
//			faculty.setDepartment(value);
//			getline(ss, value, ' ');			
//			faculty.setAddress(value);
//			getline(ss, value, ' ');
//			faculty.setCity(value);
//			getline(ss, value, ' ');
//			faculty.setState(value);			
//			getline(ss, value, ' ');
//			faculty.setZip(value);			
//			getline(ss, value, ' ');
//			faculty.setEmail(value);			
//			getline(ss, value, ' ');
//			faculty.setPhone(value);
//
//			facultyList.insert(instructorId, faculty);
//			//facultyList.insert(faculty);
//		}
//		inFile.close();
//	}
//	catch (const exception& e) {
//		cerr << "Error reading file: " << e.what() << endl;
//	}
//}
