#include "Person.h"

//Course::Course(string department, string title, string description,
//	string prerequisites, string instructor, char grade, int course, int units)
//{
//	department = department;
//	title = title;
//	description = description;
//	prerequisites = prerequisites;
//	instructor = instructor;
//	grade = grade;
//	course = course;
//	units = units;
//}
//Course::Course()
//{}
//
//Course& Course::operator=(const Course& p)
//{
//	if (this != &p)
//	{
//		department = p.department;
//		title = p.title;
//		description = p.description;
//		prerequisites = p.prerequisites;
//		instructor = p.instructor;
//		grade = p.grade;
//		course = p.course;
//		units = p.units;
//	}
//	return *this;
//}
//bool Course::operator!=(const Course& p) const
//{
//	return this->title != p.title;
//}
//bool Course::operator==(const Course& p) const
//{
//	return this->title == p.title;
//}
//ostream& operator<<(ostream& os, const Course& course)
//{
//	os << course.getDepart() << " " << course.getCourse() << endl;
//	os << course.getTitle() << endl;
//	os << course.getDescription() << endl;
//	os << course.getPrereq() << endl;
//	os << course.getUnits() << endl;
//	os << course.getInstructor() << endl;
//	os << course.getGrade() << endl;
//	return os;
//}