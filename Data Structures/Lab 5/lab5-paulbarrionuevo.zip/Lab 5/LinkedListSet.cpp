#include "LinkedListSet.h"

void LinkedListSet::insert(Course element)
{

}
void LinkedListSet::erase(Course element)
{

}
int LinkedListSet::count() const
{

}
void LinkedListSet::print()
{

}