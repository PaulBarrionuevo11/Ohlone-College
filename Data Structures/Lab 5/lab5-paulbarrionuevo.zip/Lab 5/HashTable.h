//#ifndef HASHTABLE_H
//#define HASHTABLE_H
//
//#include <vector>
//#include <functional>
//#include <iostream>
//
//using namespace std;
//
//// Forward declaration
//template <typename Key, typename Value>
//class HashTable;
//
//template <typename Key, typename Value>
//class Iterator;
//
//template <typename Key, typename Value>
//class Node {
//public:
//    Key key;
//    Value value;
//    Node<Key, Value>* next;
//
//    Node(const Key& k, const Value& v) : key(k), value(v), next(nullptr) {}
//    friend class HashTable<Key, Value>;
//    friend class Iterator<Key, Value>;
//};
//
//template <typename Key, typename Value>
//class Iterator {
//public:
//    Iterator(const HashTable<Key, Value>* table, int index, Node<Key, Value>* node)
//        : table(table), bucket_index(index), current(node) {}
//
//    void next();
//    const Key& getKey() const;
//    const Value& getValue() const;
//    bool equals(const Iterator<Key, Value>& other) const;
//
//private:
//    const HashTable<Key, Value>* table;
//    int bucket_index;
//    Node<Key, Value>* current;
//};
//
//template <typename Key, typename Value>
//class HashTable {
//public:
//    HashTable(int nbuckets);
//    ~HashTable();
//
//    int count(const Key& key) const;
//    void insert(const Key& key, const Value& value);
//    void erase(const Key& key);
//    Value& operator[](const Key& key);
//    Iterator<Key, Value> begin() const;
//    Iterator<Key, Value> end() const;
//    int size() const;
//
//private:
//    vector<Node<Key, Value>*> buckets;
//    int current_size;
//
//    int getBucketIndex(const Key& key) const;
//};
//
//#endif // HASHTABLE_H
