#ifndef COURSE_H
#define COURSE_H

#include <iostream>
using namespace std;

/*******************************************************
 * Purpose: Person class that works with the file data and manipulates
 * to get or set the values.
 *
 *******************************************************/

class Person
{
public:
	Person();
	~Person();

	// Getters
	string getInstructor() const { return instructor; }
	string getFirstName() const { return firstName; }
	string getLastName() const { return lastName; }
	string getDepartment() const { return department; }
	string getAddress() const { return address; }
	string getCity() const { return city; }
	string getState() const { return state; }
	string getEmail() const { return email; }
	int getZip() const { return zip; }
	int getPhone() const { return phone; }
	// Setters
	void setInstructor(string _instructor) { instructor = _instructor; }
	void setFirstName(string _firstName) { firstName = _firstName; }
	void setLastName(string _lastName) { lastName = _lastName; }
	void setDepartment(string _department) { department = _department; }
	void setAddress(string _address) { address = _address; }
	void setCity(string _city) { city = _city; }
	void setState(string _state) { state = _state; }
	void setEmail(string _email) { email = _email; }
	void setZip(int _zip) { zip = _zip; }
	void setPhone(int _phone) { phone = _phone; }

private:
	string instructor, firstName, lastName, department, address, city, state, email;
	int zip, phone;

};

Person::Person()
{
}

Person::~Person()
{
}

#endif // !COURSE_H