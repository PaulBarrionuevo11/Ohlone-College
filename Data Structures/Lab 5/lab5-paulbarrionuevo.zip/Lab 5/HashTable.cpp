//#include "HashTable.h"
//
//// Constructor
//template <typename Key, typename Value>
//HashTable<Key, Value>::HashTable(int nbuckets) : buckets(nbuckets, nullptr), current_size(0) {}
//
//// Destructor
//template <typename Key, typename Value>
//HashTable<Key, Value>::~HashTable() {
//    for (auto& bucket : buckets) {
//        Node<Key, Value>* current = bucket;
//        while (current) {
//            Node<Key, Value>* to_delete = current;
//            current = current->next;
//            delete to_delete;
//        }
//    }
//}
//
//// Get the bucket index for a given key
//template <typename Key, typename Value>
//int HashTable<Key, Value>::getBucketIndex(const Key& key) const {
//    int h = hash<Key>{}(key) % buckets.size();
//    if (h < 0) h += buckets.size();
//    return h;
//}
//
//// Count occurrences of a key
//template <typename Key, typename Value>
//int HashTable<Key, Value>::count(const Key& key) const {
//    int index = getBucketIndex(key);
//    Node<Key, Value>* current = buckets[index];
//    while (current) {
//        if (current->key == key) return 1;
//        current = current->next;
//    }
//    return 0;
//}
//
//// Insert a key-value pair
//template <typename Key, typename Value>
//void HashTable<Key, Value>::insert(const Key& key, const Value& value) {
//    int index = getBucketIndex(key);
//    Node<Key, Value>* current = buckets[index];
//    while (current) {
//        if (current->key == key) {
//            current->value = value; // Update existing key
//            return;
//        }
//        current = current->next;
//    }
//    // Insert a new node
//    Node<Key, Value>* new_node = new Node<Key, Value>(key, value);
//    new_node->next = buckets[index];
//    buckets[index] = new_node;
//    current_size++;
//}
//
//// Erase a key-value pair
//template <typename Key, typename Value>
//void HashTable<Key, Value>::erase(const Key& key) {
//    int index = getBucketIndex(key);
//    Node<Key, Value>* current = buckets[index];
//    Node<Key, Value>* previous = nullptr;
//
//    while (current) {
//        if (current->key == key) {
//            if (previous) {
//                previous->next = current->next;
//            }
//            else {
//                buckets[index] = current->next;
//            }
//            delete current;
//            current_size--;
//            return;
//        }
//        previous = current;
//        current = current->next;
//    }
//}
//
//// Access value by key
//template <typename Key, typename Value>
//Value& HashTable<Key, Value>::operator[](const Key& key) {
//    int index = getBucketIndex(key);
//    Node<Key, Value>* current = buckets[index];
//    while (current) {
//        if (current->key == key) return current->value;
//        current = current->next;
//    }
//    // If key does not exist, insert it with a default value
//    insert(key, Value());
//    return buckets[index]->value;
//}
//
//// Get size of the hash table
//template <typename Key, typename Value>
//int HashTable<Key, Value>::size() const {
//    return current_size;
//}
//
//// Begin iterator
//template <typename Key, typename Value>
//Iterator<Key, Value> HashTable<Key, Value>::begin() const {
//    for (int i = 0; i < buckets.size(); i++) {
//        if (buckets[i]) return Iterator<Key, Value>(this, i, buckets[i]);
//    }
//    return end();
//}
//
//// End iterator
//template <typename Key, typename Value>
//Iterator<Key, Value> HashTable<Key, Value>::end() const {
//    return Iterator<Key, Value>(this, buckets.size(), nullptr);
//}
//
//// Iterator: Advance to the next element
//template <typename Key, typename Value>
//void Iterator<Key, Value>::next() {
//    if (current && current->next) {
//        current = current->next;
//    }
//    else {
//        do {
//            bucket_index++;
//        } while (bucket_index < table->buckets.size() && !table->buckets[bucket_index]);
//        current = bucket_index < table->buckets.size() ? table->buckets[bucket_index] : nullptr;
//    }
//}
//
//// Iterator: Get key
//template <typename Key, typename Value>
//const Key& Iterator<Key, Value>::getKey() const {
//    return current->key;
//}
//
//// Iterator: Get value
//template <typename Key, typename Value>
//const Value& Iterator<Key, Value>::getValue() const {
//    return current->value;
//}
//
//// Iterator: Compare equality
//template <typename Key, typename Value>
//bool Iterator<Key, Value>::equals(const Iterator<Key, Value>& other) const {
//    return current == other.current;
//}
