//#ifndef FACULTY_LIST_H
//#define FACULTY_LIST_H
//
//#include <iostream>
//#include "Faculty.h"
//#include "HashTable.h"
//
//using namespace std;
//
//class FacultyList
//{
//public:
//	void init();
//private:
//	HashTable<string, Faculty> facultyList; // Map of <Instructor ID, Faculty>
//};
//#endif // !FACULTY_LIST_H
